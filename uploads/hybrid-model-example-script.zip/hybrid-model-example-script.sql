CREATE TABLE "public"."users" (
"id" serial NOT NULL,
"name" varchar(255) COLLATE "default" NOT NULL,
"password" text COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE "public"."users" ADD PRIMARY KEY ("id");

CREATE TABLE "public"."clients" (
"id" serial NOT NULL,
"user_id" int4 NOT NULL,
"full_name" text COLLATE "default" NOT NULL,
"account_number" text COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE);

CREATE INDEX "idx_user_id" ON "public"."clients" USING btree (user_id);

ALTER TABLE "public"."clients" ADD PRIMARY KEY ("id");

ALTER TABLE "public"."clients" ADD FOREIGN KEY ("user_id") REFERENCES "public"."users" ("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "public"."forms" (
"id" serial NOT NULL,
"client_id" int4 NOT NULL,
"data" json DEFAULT '{}'::json
)
WITH (OIDS=FALSE);

ALTER TABLE "public"."forms" ADD PRIMARY KEY ("id");

ALTER TABLE "public"."forms" ADD FOREIGN KEY ("client_id") REFERENCES "public"."clients" ("id") ON DELETE CASCADE ON UPDATE CASCADE;